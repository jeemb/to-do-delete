-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Feb 21, 2017 at 11:28 PM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `to_do`
--
CREATE DATABASE IF NOT EXISTS `to_do` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `to_do`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Home'),
(2, 'Work'),
(3, 'Kids'),
(4, 'Community'),
(5, 'House'),
(6, 'House'),
(7, 'fun stuff'),
(8, 'fun stuff'),
(9, ''),
(10, 'home'),
(11, 'special'),
(12, 'sdfaf'),
(13, 'sadf'),
(14, 'sdaf'),
(15, 'sdaf'),
(16, 'sdaf'),
(17, 'sadffsad');

-- --------------------------------------------------------

--
-- Table structure for table `dates`
--

CREATE TABLE `dates` (
  `id` bigint(20) unsigned NOT NULL,
  `date` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dates`
--

INSERT INTO `dates` (`id`, `date`) VALUES
(1, '2017-02-22'),
(2, '2017-02-22'),
(3, '2017-02-07'),
(4, '2017-02-07'),
(5, ''),
(6, '2017-02-22'),
(7, '02-22-2017'),
(8, '03-04-2017'),
(9, '2017-02-22'),
(10, '2017-03-03'),
(11, '2017-03-03'),
(12, '2017-03-03'),
(13, '2017-04-13');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint(20) unsigned NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `importance` int(11) DEFAULT NULL,
  `date_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `description`, `category_id`, `importance`, `date_id`) VALUES
(1, 'Wash Clothes', 1, NULL, NULL),
(2, 'Wash Dishes', 1, NULL, NULL),
(3, 'Plan Meals', 1, NULL, NULL),
(4, 'Send emails', 2, NULL, NULL),
(5, 'write software', 2, NULL, NULL),
(6, 'Do the dishes', 5, 2, 1),
(7, 'Do the dishes', 6, 2, 2),
(8, 'Walk the Dog', 7, 1, 3),
(9, 'Walk the Dog', 8, 1, 4),
(10, '', 9, 1, 5),
(11, 'homework', 10, 2, 6),
(12, 'NEW THing to do', 11, 1, 7),
(13, 'thest 2', 12, 1, 8),
(14, 'test 2', 13, 1, 9),
(15, 'way in the future', 14, 1, 10),
(16, 'way in the future', 15, 1, 11),
(17, 'way in the future', 16, 1, 12),
(18, 'not importand and distant', 17, 2, 13);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `dates`
--
ALTER TABLE `dates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `dates`
--
ALTER TABLE `dates`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
